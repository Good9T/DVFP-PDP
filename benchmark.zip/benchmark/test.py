import os

for f in os.listdir('.'):
    if f.endswith('.pdl'):
        new_name = f[:-4] + '.txt'
        os.rename(f, new_name)
        print(f'{f} -> {new_name}')